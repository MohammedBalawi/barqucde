import 'dart:io';
import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:excel/excel.dart';
import 'package:barcode/barcode.dart' as bc;
import 'package:flutter/services.dart';
import 'package:flutter_barcode_scanner/flutter_barcode_scanner.dart';
import 'package:file_picker/file_picker.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../shared_pref/shared.dart';

class TextController extends GetxController {
  var text = ''.obs;
  List<Map<String, String>> data = [];
  List<bool> selected = [];
  XFile? customImage;
  String customText = '';

  @override
  void onInit() {
    super.onInit();
    loadText();
  }

  void updateText(String newText) async {
    text.value = newText;
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString('savedText', newText);
  }

  void loadText() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    text.value = prefs.getString('savedText') ?? '';
  }
}

class BarcodeGenerator extends StatefulWidget {
  const BarcodeGenerator({super.key});

  @override
  _BarcodeGeneratorState createState() => _BarcodeGeneratorState();
}

class _BarcodeGeneratorState extends State<BarcodeGenerator> {
  List<Map<String, String>> data = [];
  List<bool> selected = [];
  XFile? customImage;
  String customText = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Make QR Code',
          style: GoogleFonts.aBeeZee(),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Center(
              child: Container(
                height: 40,
                width: 100,
                decoration: BoxDecoration(
                    color: Colors.red, borderRadius: BorderRadius.circular(40)),
                child: Center(
                    child: InkWell(
                        onTap: () {
                          // Navigator.pushReplacementNamed(context, '/login_screen');
                          // _logout();
                          // _claer();
                          _showM(context);
                        },
                        child: Text(
                          'logout',
                          style: GoogleFonts.aBeeZee(color: Colors.white),
                        ))),
              ),
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ElevatedButton(
                onPressed: _pickExcelFile,
                child: Text(
                  'Upload Excel File',
                  style: GoogleFonts.aBeeZee(color: Colors.green),
                ),
              ),
              const SizedBox(
                width: 10,
              ),
              ElevatedButton(
                onPressed: _pickExcelFileWiFi,
                child: const Icon(
                  Icons.wifi,
                  color: Colors.green,
                ),
              ),
            ],
          ),
          Expanded(
            child: ListView.builder(
              itemCount: data.length,
              itemBuilder: (context, index) {
                return ListTile(
                  leading: Checkbox(
                    value: selected[index],
                    onChanged: (value) {
                      setState(() {
                        selected[index] = value!;
                      });
                    },
                  ),
                  title: SvgPicture.string(
                    _generateQRCode(data[index]['info']!),
                    height: 100,
                  ),
                  subtitle: Text(data[index]['subtitle']!),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: _selectAll,
                  child: Text(
                    'Select All',
                    style: GoogleFonts.aBeeZee(color: Colors.black),
                  ),
                ),
                ElevatedButton(
                  onPressed: _download,
                  // _download,
                  child: Text(
                    'Download Selected',
                    style: GoogleFonts.aBeeZee(color: Colors.green),
                  ),
                ),
                ElevatedButton(
                  onPressed: () {
                    Navigator.pushReplacementNamed(context, '/my_cv_screen');
                  },
                  child: Text(
                    'Mohammed Balawi',
                    style: GoogleFonts.aBeeZee(color: Colors.grey),
                  ),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }

  Future<void> _pickExcelFile() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['xlsx'],
    );

    if (result != null) {
      var bytes = File(result.files.single.path!).readAsBytesSync();
      var excel = Excel.decodeBytes(bytes);

      setState(() {
        data.clear();
        selected.clear();
        for (var table in excel.tables.keys) {
          for (var row in excel.tables[table]!.rows) {
            String allData =
                row.map((cell) => cell?.value.toString() ?? '').join(', ');
            String subtitle = row[1]?.value.toString() ?? '';
            data.add({'info': allData, 'subtitle': subtitle});
            selected.add(false); // Select all by default
          }
        }
      });
    }
  }

  Future<void> _pickExcelFileWiFi() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['xlsx'],
    );

    if (result != null) {
      var bytes = File(result.files.single.path!).readAsBytesSync();
      var excel = Excel.decodeBytes(bytes);

      setState(() {
        data.clear();
        selected.clear();
        for (var table in excel.tables.keys) {
          for (var row in excel.tables[table]!.rows) {
            // Assuming the barcode is constructed from the third and fourth columns
            String part1 = row[2]?.value.toString() ?? '';
            String part2 = row[3]?.value.toString() ?? '';
            String barcode = row[1]?.value.toString() ?? '';

            // Assuming user and password are also in the third and fourth columns
            String user = row[2]?.value.toString() ?? '';
            String password = row[3]?.value.toString() ?? '';

            // Construct the URL
            String url = 'http://$barcode/login?user=$user&password=$password';

            // Prepare the data entry
            String allData =
                row.map((cell) => cell?.value.toString() ?? '').join(', ');
            String subtitle = row[1]?.value.toString() ?? '';
            String subtitle1 = row[2]?.value.toString() ?? '';
            String subtitle2 = row[3]?.value.toString() ?? '';
            data.add({
              'info': url,
              'subtitle': subtitle,
              'url': allData,
              'user': subtitle1,
              'password': subtitle2
            });
            selected.add(false); // Select all by default
          }
        }
      });
    }
  }

  var text = ''.obs;

  String _generateQRCode(String input) {
    final qrCode = bc.Barcode.qrCode();
    return qrCode.toSvg(input, width: 200, height: 200);
  }

  void _selectAll() {
    setState(() {
      for (int i = 1; i < selected.length; i++) {
        selected[i] = true;
      }
    });
  }

  void updateText(String newText) async {
    text.value = newText;
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString('savedText', newText);
  }

  void loadText() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    text.value = prefs.getString('savedText') ?? '';
  }

  final TextController textController = Get.put(TextController());

  Future<void> _showTextInputDialog(BuildContext context) async {
    final TextEditingController inputController = TextEditingController();
    return showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Enter Text'),
          content: TextField(
            controller: inputController,
            decoration: const InputDecoration(
              hintText: 'Enter Text Here',
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('Cancel'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
                child: const Text('Save'),
                onPressed: () {
                  textController.updateText(inputController.text);
                  Navigator.of(context).pop();
                }),
          ],
        );
      },
    );
  }

  void _showM(BuildContext context) async {
    bool result = await showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: const Text('Logout'),
            content: const Text('Do You Logout New ?'),
            actions: [
              MaterialButton(
                onPressed: () {
                  Navigator.pushReplacementNamed(context, '/login_screen');
                },
                child: const Text(
                  'Yes',
                  style: TextStyle(color: Colors.blue),
                ),
              ),
              MaterialButton(
                onPressed: () {
                  Navigator.pop(context, false);
                },
                child: const Text(
                  'No',
                  style: TextStyle(color: Colors.red),
                ),
              ),
            ],
          );
        });
    if (result ?? false) {
      _claer(context);
    }
  }

  void _showMo(BuildContext context) async {
    bool result = await showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: const Text('Text'),
            actions: [
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  ElevatedButton(
                    onPressed: () => _showTextInputDialog(context),
                    child: const Text(
                      'Enter Text',
                      style: TextStyle(color: Colors.black),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Obx(() {
                    return Text(
                      textController.text.value,
                      style: const TextStyle(fontSize: 20),
                    );
                  }),
                  MaterialButton(
                    onPressed: () {
                      Navigator.pop(context, false);
                    },
                    child: Container(
                      decoration: BoxDecoration(
                          color: Colors.indigoAccent,
                          borderRadius: BorderRadius.circular(10)),
                      child: const Center(
                        child: Text(
                          'ok',
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          );
        });
    if (result ?? false) {
      _claer(context);
    }
  }

  Future<void> _claer(BuildContext context) async {
    bool clear = await SharedPrefController().clear();

    if (clear) {
      Get.delete();
      Navigator.pushReplacementNamed(context, '/login_screen');
    }
  }

// 21 barcode in file + image + text .
  void _downloadSelected21() async {
    final pdf = pw.Document();
    final fontData = await rootBundle.load('fonts/Cairo-Regular.ttf');
    final ttf = pw.Font.ttf(fontData);

    final imageBytes =
        (await rootBundle.load('assets/download.jpeg')).buffer.asUint8List();
    final image = pw.MemoryImage(imageBytes);

    final items = <pw.Widget>[];

    for (int i = 0; i < data.length; i++) {
      if (selected[i]) {
        final info = data[i]['info']!;
        final subtitle = data[i]['subtitle']!;
        final firstColumn = data[i]['info']!
            .split(',')[0]; // Assuming first column data is here
        final svg = _generateQRCode(info);
        final thirdColumn = data[i]['third'] ?? '';

        items.add(
          pw.Row(
            children: [
              pw.Padding(
                padding: const pw.EdgeInsetsDirectional.only(bottom: 15),
                child: pw.SvgImage(svg: svg, height: 90, width: 90),
              ),
              pw.Column(
                mainAxisAlignment: pw.MainAxisAlignment.start,
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Container(
                    height: 90,
                    width: 90,
                    decoration: pw.BoxDecoration(
                      borderRadius: pw.BorderRadius.circular(30),
                    ),
                    child: pw.Column(children: [
                      pw.Container(
                          height: 40,
                          width: 40,
                          decoration: pw.BoxDecoration(
                            borderRadius: pw.BorderRadius.circular(30),
                          ),
                          child: textController.text == 'PARC' ||
                                  textController.text == 'Wael'
                              ? pw.Image(image)
                              :
                              // (option)?true:false
                              pw.Container(
                                  height: 20,
                                  width: 90,
                                  decoration: pw.BoxDecoration(
                                      color: PdfColors.grey,
                                      borderRadius:
                                          pw.BorderRadius.circular(10)),
                                  child: pw.Center(
                                    child: pw.Text('image',
                                        style: const pw.TextStyle(
                                          color: PdfColors.black,
                                        )),
                                  ))),
                      pw.Text(
                        textController.text.value,
                        style: pw.TextStyle(
                            fontSize: 11,
                            font: ttf,
                            fontWeight: pw.FontWeight.bold),
                        textAlign: pw.TextAlign.center,
                      ),
                      pw.Text(
                        firstColumn,
                        style: pw.TextStyle(fontSize: 7, font: ttf),
                        textAlign: pw.TextAlign.center,
                      ),
                      pw.Text(
                        subtitle,
                        style: pw.TextStyle(
                            fontSize: 7,
                            font: ttf,
                            fontWeight: pw.FontWeight.bold),
                        textAlign: pw.TextAlign.center,
                      ),
                    ]),
                  ),
                ],
              ),
            ],
          ),
        );
      }
    }

    int pageCount = (items.length / 16).ceil();
    for (int page = 0; page < pageCount; page++) {
      pdf.addPage(
        pw.Page(
          build: (pw.Context context) {
            return pw.GridView(
              crossAxisCount: 3,
              childAspectRatio: 1,
              children: items.skip(page * 21).take(21).toList(),
            );
          },
        ),
      );
    }

    final directory = await getApplicationDocumentsDirectory();
    final filePath = '${directory.path}/barcodes.pdf';
    final file = File(filePath);
    await file.writeAsBytes(await pdf.save());

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('All QR codes saved to $filePath'),
      ),
    );
  }

// 97 barcode in file .
  void _downloadSelected97() async {
    final pdf = pw.Document();
    final fontData = await rootBundle.load('fonts/Cairo-Regular.ttf');
    final ttf = pw.Font.ttf(fontData);

    final imageBytes =
        (await rootBundle.load('assets/download.jpeg')).buffer.asUint8List();
    final image = pw.MemoryImage(imageBytes);

    final items = <pw.Widget>[];

    for (int i = 0; i < data.length; i++) {
      if (selected[i]) {
        final info = data[i]['info']!;
        final subtitle = data[i]['subtitle']!;
        final firstColumn = data[i]['info']!
            .split(',')[0]; // Assuming first column data is here
        final svg = _generateQRCode(info);
        final thirdColumn = data[i]['third'] ?? '';

        items.add(
          pw.Column(children: [
            pw.SvgImage(svg: svg, height: 50, width: 50),
            pw.Row(
              mainAxisAlignment: pw.MainAxisAlignment.center,
              children: [
                pw.Text(
                  firstColumn,
                  style: pw.TextStyle(fontSize: 4, font: ttf),
                  textAlign: pw.TextAlign.end,
                ),
                pw.Text(
                  ' --- ',
                  style: const pw.TextStyle(
                    fontSize: 2,
                  ),
                ),
                pw.Text(
                  subtitle,
                  style: pw.TextStyle(
                      fontSize: 4, font: ttf, fontWeight: pw.FontWeight.bold),
                  textAlign: pw.TextAlign.end,
                ),
              ],
            ),
          ]),

          // ),
        );
      }
    }

    int pageCount = (items.length / 64).ceil();
    for (int page = 0; page < pageCount; page++) {
      pdf.addPage(
        pw.Page(
          build: (pw.Context context) {
            return pw.GridView(
              crossAxisCount: 8,
              childAspectRatio: 1,
              children: items.skip(page * 96).take(96).toList(),
            );
          },
        ),
      );
    }

    final directory = await getApplicationDocumentsDirectory();
    final filePath = '${directory.path}/barcodes.pdf';
    final file = File(filePath);
    await file.writeAsBytes(await pdf.save());

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('All QR codes saved to $filePath'),
      ),
    );
  }

// 54 barcode in file without text .
  void _downloadSelected54() async {
    final pdf = pw.Document();
    final fontData = await rootBundle.load('fonts/Cairo-Regular.ttf');
    final ttf = pw.Font.ttf(fontData);

    final imageBytes =
        (await rootBundle.load('assets/download.jpeg')).buffer.asUint8List();
    final image = pw.MemoryImage(imageBytes);

    final items = <pw.Widget>[];

    for (int i = 0; i < data.length; i++) {
      if (selected[i]) {
        final info = data[i]['info']!;
        final subtitle = data[i]['subtitle']!;
        final firstColumn = data[i]['info']!
            .split(',')[0]; // Assuming first column data is here
        final svg = _generateQRCode(info);
        final thirdColumn = data[i]['third'] ?? '';

        items.add(
          pw.Row(
            children: [
              pw.Padding(
                padding: const pw.EdgeInsetsDirectional.only(bottom: 15),
                child: pw.SvgImage(svg: svg, height: 90, width: 90),
              ),
              pw.Column(
                mainAxisAlignment: pw.MainAxisAlignment.start,
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Container(
                    height: 90,
                    width: 90,
                    decoration: pw.BoxDecoration(
                      borderRadius: pw.BorderRadius.circular(30),
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      }
    }

    int pageCount = (items.length / 64).ceil();
    for (int page = 0; page < pageCount; page++) {
      pdf.addPage(
        pw.Page(
          build: (pw.Context context) {
            return pw.GridView(
              crossAxisCount: 6,
              childAspectRatio: 1,
              children: items.skip(page * 54).take(54).toList(),
            );
          },
        ),
      );
    }

    final directory = await getApplicationDocumentsDirectory();
    final filePath = '${directory.path}/barcodes.pdf';
    final file = File(filePath);
    await file.writeAsBytes(await pdf.save());

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('All QR codes saved to $filePath'),
      ),
    );
  }

// 40 barcode in file without image .
  void _downloadSelected40() async {
    final pdf = pw.Document();
    final fontData = await rootBundle.load('fonts/Cairo-Regular.ttf');
    final ttf = pw.Font.ttf(fontData);

    final imageBytes =
        (await rootBundle.load('assets/download.jpeg')).buffer.asUint8List();
    final image = pw.MemoryImage(imageBytes);

    final items = <pw.Widget>[];

    for (int i = 0; i < data.length; i++) {
      if (selected[i]) {
        final info = data[i]['info']!;
        final subtitle = data[i]['subtitle']!;
        final firstColumn = data[i]['info']!
            .split(',')[0]; // Assuming first column data is here
        final svg = _generateQRCode(info);
        final thirdColumn = data[i]['third'] ?? '';

        items.add(
          pw.Row(
            children: [
              pw.Padding(
                padding:
                    const pw.EdgeInsetsDirectional.only(bottom: 10, end: 10),
                child: pw.SvgImage(svg: svg, height: 70, width: 70),
              ),
              pw.Column(
                  mainAxisAlignment: pw.MainAxisAlignment.center,
                  crossAxisAlignment: pw.CrossAxisAlignment.center,
                  children: [
                    pw.Text(
                      textController.text.value ?? 'MoBa',
                      style: pw.TextStyle(
                          fontSize: 7,
                          font: ttf,
                          fontWeight: pw.FontWeight.bold),
                      textAlign: pw.TextAlign.center,
                    ),
                    pw.Text(
                      firstColumn,
                      style: pw.TextStyle(
                          fontSize: 7,
                          fontWeight: pw.FontWeight.bold,
                          font: ttf),
                      textAlign: pw.TextAlign.center,
                    ),
                    pw.Text(
                      subtitle,
                      style: pw.TextStyle(
                          fontSize: 7,
                          font: ttf,
                          fontWeight: pw.FontWeight.bold),
                      textAlign: pw.TextAlign.center,
                    ),
                  ]),
            ],
          ),
        );
      }
    }

    int pageCount = (items.length / 16).ceil();
    for (int page = 0; page < pageCount; page++) {
      pdf.addPage(
        pw.Page(
          build: (pw.Context context) {
            return pw.GridView(
              crossAxisCount: 4,
              childAspectRatio: 1,
              children: items.skip(page * 40).take(40).toList(),
            );
          },
        ),
      );
    }

    final directory = await getApplicationDocumentsDirectory();
    final filePath = '${directory.path}/barcodes.pdf';
    final file = File(filePath);
    await file.writeAsBytes(await pdf.save());

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('All QR codes saved to $filePath'),
      ),
    );
  }

//70 barcode in file to wifi .
  void _downloadSelected70() async {
    final pdf = pw.Document();
    final fontData = await rootBundle.load('fonts/Cairo-Regular.ttf');
    final ttf = pw.Font.ttf(fontData);

    final imageBytes =
        (await rootBundle.load('assets/download.jpeg')).buffer.asUint8List();
    final image = pw.MemoryImage(imageBytes);

    final items = <pw.Widget>[];

    for (int i = 0; i < data.length; i++) {
      if (selected[i]) {
        final info = data[i]['info']!;
        final subtitle = data[i]['subtitle']!;
        final subtitle1 = data[i]['user']!;
        final subtitle2 = data[i]['password']!;
        final firstColumn = data[i]['info']!
            .split(',')[0]; // Assuming first column data is here
        final svg = _generateQRCode(info);

        items.add(
          pw.Row(
            children: [
              pw.Padding(
                padding:
                    const pw.EdgeInsetsDirectional.only(bottom: 10, end: 10),
                child: pw.SvgImage(svg: svg, height: 50, width: 50),
              ),
              pw.Column(
                  mainAxisAlignment: pw.MainAxisAlignment.center,
                  crossAxisAlignment: pw.CrossAxisAlignment.center,
                  children: [
                    pw.Text(
                      textController.text.value ?? 'MoBa',
                      style: pw.TextStyle(
                          fontSize: 7,
                          font: ttf,
                          fontWeight: pw.FontWeight.bold),
                      textAlign: pw.TextAlign.center,
                    ),
                    pw.Text(
                      subtitle1,
                      style: pw.TextStyle(
                          fontSize: 7,
                          fontWeight: pw.FontWeight.bold,
                          font: ttf),
                      textAlign: pw.TextAlign.center,
                    ),
                    pw.Text(
                      subtitle2,
                      style: pw.TextStyle(
                          fontSize: 7,
                          font: ttf,
                          fontWeight: pw.FontWeight.bold),
                      textAlign: pw.TextAlign.center,
                    ),
                  ]),
            ],
          ),
        );
      }
    }

    int pageCount = (items.length / 16).ceil();
    for (int page = 0; page < pageCount; page++) {
      pdf.addPage(
        pw.Page(
          build: (pw.Context context) {
            return pw.GridView(
              crossAxisCount: 5,
              childAspectRatio: 1,
              children: items.skip(page * 70).take(70).toList(),
            );
          },
        ),
      );
    }

    final directory = await getApplicationDocumentsDirectory();
    final filePath = '${directory.path}/barcodes.pdf';
    final file = File(filePath);
    await file.writeAsBytes(await pdf.save());

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('All QR codes saved to $filePath'),
      ),
    );
  }

  void _scanOptions() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Scan Options'),
        content: const Text('Choose a method to scan the QR code.'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              _scanBarcode();
            },
            child: const Text('Camera'),
          ),
        ],
      ),
    );
  }

  Future<void> _scanBarcode() async {
    String barcodeScanRes = await FlutterBarcodeScanner.scanBarcode(
        '#ff6666', 'Cancel', true, ScanMode.QR);

    _showBarcodeInfo(barcodeScanRes);
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  void _showBarcodeInfo(String barcodeScanRes) {
    for (var item in data) {
      if (item['info'] == barcodeScanRes) {
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('QR Code Information'),
            content: Text(item['subtitle']!),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('OK'),
              ),
            ],
          ),
        );
        break;
      }
    }
  }

  void _download() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Download Options'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // 97 in file .
                GestureDetector(
                  onTap: () {
                    _executeFirstImageCode();
                    Navigator.of(context).pop();
                  },
                  child: Container(
                      height: 197,
                      width: 200,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20)),
                      child: Column(
                        children: [
                          Image.asset('assets/image_1.png'),
                          const Text('97 barcode in file'),
                        ],
                      )),
                ),
                const Text('_________________________'),
                const SizedBox(
                  height: 10,
                ),
                // 21 in file .
                GestureDetector(
                  onTap: () {
                    _executeSecondImageCode();
                    Navigator.of(context).pop();
                  },
                  child: Container(
                    height: 300,
                    width: 230,
                    decoration:
                        BoxDecoration(borderRadius: BorderRadius.circular(20)),
                    child: Column(
                      children: [
                        Image.asset('assets/image_2.png'),
                        const Text('21 barcode in file'),
                        const SizedBox(
                          height: 10,
                        ),
                        ElevatedButton(
                            onPressed: () {
                              setState(() {
                                _showMo(context);
                              });
                            },
                            child: const Text(
                              'Enter Text ?',
                              style: TextStyle(color: Colors.black87),
                            )),
                      ],
                    ),
                  ),
                ),
                const Text('_________________________'),
                const SizedBox(
                  height: 10,
                ),
                // 54 in file .
                GestureDetector(
                  onTap: () {
                    _downloadSelected54();
                    Navigator.of(context).pop();
                  },
                  child: Container(
                    height: 300,
                    width: 235,
                    decoration:
                        BoxDecoration(borderRadius: BorderRadius.circular(20)),
                    child: Column(
                      children: [
                        Image.asset('assets/image_3.png'),
                        const Text('54 barcode in file'),
                      ],
                    ),
                  ),
                ),
                const Text('_________________________'),
                const SizedBox(
                  height: 10,
                ),
                // 40 in file .
                GestureDetector(
                  onTap: () {
                    _downloadSelected40();
                    Navigator.of(context).pop();
                  },
                  child: Container(
                    height: 300,
                    width: 200,
                    decoration:
                        BoxDecoration(borderRadius: BorderRadius.circular(20)),
                    child: Column(
                      children: [
                        Image.asset('assets/image_4.png'),
                        const Text('40 barcode in file'),
                        const SizedBox(
                          height: 10,
                        ),
                        ElevatedButton(
                            onPressed: () {
                              setState(() {
                                _showMo(context);
                              });
                            },
                            child: const Text(
                              'Enter Text ?',
                              style: TextStyle(color: Colors.black87),
                            ))
                      ],
                    ),
                  ),
                ),
                const Text('_________________________'),
                const SizedBox(
                  height: 10,
                ),
                // 70 in file .
                GestureDetector(
                  onTap: () {
                    _downloadSelected70();
                    Navigator.of(context).pop();
                  },
                  child: Container(
                    height: 300,
                    width: 200,
                    decoration:
                        BoxDecoration(borderRadius: BorderRadius.circular(20)),
                    child: Column(
                      children: [
                        Image.asset('assets/image_4.png'),
                        const Text('70 barcode in file to wifi'),
                        const SizedBox(
                          height: 10,
                        ),
                        ElevatedButton(
                            onPressed: () {
                              setState(() {
                                _showMo(context);
                              });
                            },
                            child: const Text(
                              'Enter Text ?',
                              style: TextStyle(color: Colors.black87),
                            ))
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('Close'),
            ),
          ],
        );
      },
    );
  }

  void _executeFirstImageCode() {
    // 97 in file .
    _downloadSelected97();
    print('97 barcode in file');
  }

  void _executeSecondImageCode() {
    // 21 in file .
    _downloadSelected21();
    print('21 barcode in file');
  }

  void _executeThirdImageCode() {
    // 54 in file .
    _downloadSelected54();
    print('54 barcode in file');
  }

  void _executeFourImageCode() {
    // 40 in file .
    _downloadSelected40();
    print('40 barcode in file');
  }
}
