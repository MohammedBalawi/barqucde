import 'package:barqucde/login_screen/login_screen.dart';
import 'package:barqucde/make_qr/qr.dart';
import 'package:barqucde/shared_pref/shared.dart';
import 'package:flutter/material.dart';
import 'cv/my_cv_screen.dart';
import 'launch_screen/launch_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SharedPrefController().initPreferences();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      initialRoute: '/launch_screen',
      routes: {
        '/barcode_generator': (context) => const BarcodeGenerator(),
        '/launch_screen': (context) => const LaunchScreen(),
        '/my_cv_screen': (context) => const MyCVScreen(),
        '/login_screen': (context) => LoginScreen(),
      },
    );
  }
}
