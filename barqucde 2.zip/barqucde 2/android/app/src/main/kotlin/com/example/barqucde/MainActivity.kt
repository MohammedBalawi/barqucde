package com.example.barqucde

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
